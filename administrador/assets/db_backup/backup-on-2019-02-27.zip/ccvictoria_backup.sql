#
# TABLE STRUCTURE FOR: avisos
#

DROP TABLE IF EXISTS `avisos`;

CREATE TABLE `avisos` (
  `idAvisos` int(11) NOT NULL AUTO_INCREMENT,
  `Contenido` varchar(500) NOT NULL,
  PRIMARY KEY (`idAvisos`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `avisos` (`idAvisos`, `Contenido`) VALUES (5, 'Esta es una prueba de aviso para la página del Centro Comercial La Victoria');
INSERT INTO `avisos` (`idAvisos`, `Contenido`) VALUES (6, 'Este es un segundo aviso para la pagina del CCV');
INSERT INTO `avisos` (`idAvisos`, `Contenido`) VALUES (10, 'Ya hay Pulpopapas');


#
# TABLE STRUCTURE FOR: comentarios
#

DROP TABLE IF EXISTS `comentarios`;

CREATE TABLE `comentarios` (
  `idComentarios` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Descripcion` varchar(500) NOT NULL,
  PRIMARY KEY (`idComentarios`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: empleo
#

DROP TABLE IF EXISTS `empleo`;

CREATE TABLE `empleo` (
  `idEmpleos` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(100) DEFAULT NULL,
  `Horario` varchar(30) DEFAULT NULL,
  `Sueldo` varchar(30) DEFAULT NULL,
  `Atencion` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idEmpleos`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `empleo` (`idEmpleos`, `Nombre`, `Descripcion`, `Horario`, `Sueldo`, `Atencion`) VALUES (1, 'Ayudante', 'Despachar', '9:00 - 15:00', '$1300.00', '10:00');
INSERT INTO `empleo` (`idEmpleos`, `Nombre`, `Descripcion`, `Horario`, `Sueldo`, `Atencion`) VALUES (4, 'Prueba', 'Probadores', '9:00 - 20:00', '$2000.00 Quincenales', '11:00 en Adelante');


#
# TABLE STRUCTURE FOR: evento
#

DROP TABLE IF EXISTS `evento`;

CREATE TABLE `evento` (
  `idEvento` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  `Lugar` varchar(45) NOT NULL,
  `Descripcion` varchar(45) DEFAULT NULL,
  `FechaEvento` varchar(45) DEFAULT NULL,
  `Horario` varchar(45) DEFAULT NULL,
  `Imagen` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idEvento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `evento` (`idEvento`, `Nombre`, `Lugar`, `Descripcion`, `FechaEvento`, `Horario`, `Imagen`) VALUES (3, 'Catrina', 'Cholula', 'Concierto', '12/03/2019', '3:00 a 12:00', 'evento_3.jpg');
INSERT INTO `evento` (`idEvento`, `Nombre`, `Lugar`, `Descripcion`, `FechaEvento`, `Horario`, `Imagen`) VALUES (4, 'Navidad', 'Donde Sea', 'Celebra la Navidad', '25/12/2019', '10:00 a 18:00', 'evento_2.jpg');


#
# TABLE STRUCTURE FOR: fotos
#

DROP TABLE IF EXISTS `fotos`;

CREATE TABLE `fotos` (
  `idFotos` int(11) NOT NULL,
  `Nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`idFotos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: giro
#

DROP TABLE IF EXISTS `giro`;

CREATE TABLE `giro` (
  `idGiro` int(11) NOT NULL AUTO_INCREMENT,
  `Categoria` int(11) NOT NULL,
  PRIMARY KEY (`idGiro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: girotienda
#

DROP TABLE IF EXISTS `girotienda`;

CREATE TABLE `girotienda` (
  `Giro_idGiro` int(11) NOT NULL,
  `Tienda_idTienda` int(11) NOT NULL,
  PRIMARY KEY (`Giro_idGiro`,`Tienda_idTienda`),
  KEY `fk_Giro_has_Tienda_Tienda1_idx` (`Tienda_idTienda`),
  KEY `fk_Giro_has_Tienda_Giro1_idx` (`Giro_idGiro`),
  CONSTRAINT `fk_Giro_has_Tienda_Giro1` FOREIGN KEY (`Giro_idGiro`) REFERENCES `giro` (`idGiro`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Giro_has_Tienda_Tienda1` FOREIGN KEY (`Tienda_idTienda`) REFERENCES `tienda` (`idTienda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: local
#

DROP TABLE IF EXISTS `local`;

CREATE TABLE `local` (
  `idLocal` int(11) NOT NULL AUTO_INCREMENT,
  `NombreL` varchar(10) NOT NULL,
  PRIMARY KEY (`idLocal`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;

INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (1, '1');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (2, '2');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (3, '3');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (4, '4');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (5, '5');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (6, '6');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (7, '7');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (8, '8');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (9, '9');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (10, '10');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (11, '11');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (12, '12');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (13, '13');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (14, '14');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (15, '16');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (16, '17');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (17, '18');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (18, '19');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (19, '20');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (20, '22');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (21, '23');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (22, '24');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (23, '25');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (24, '26');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (25, '27');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (26, '29');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (27, '31');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (28, '32');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (29, '32A');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (30, '33');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (31, '34-37');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (32, '38');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (33, '39');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (34, '40');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (35, '41');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (36, '42');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (37, '43');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (38, '44');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (39, '45');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (40, '46');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (41, '47');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (42, '48');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (43, '49');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (44, '50');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (45, '51');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (46, '52');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (47, '53');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (48, '54');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (49, '55');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (50, '80');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (51, '56 ');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (52, '57');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (53, '58');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (54, '59');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (55, '60');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (56, '61');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (57, '62');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (58, '63');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (59, 'A');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (60, 'B');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (61, 'C');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (62, 'CH');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (63, 'D');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (64, 'E');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (65, 'F');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (66, 'G');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (67, 'H');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (68, 'I ');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (69, 'J');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (70, 'K');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (71, 'L');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (72, 'LL');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (73, 'M ');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (74, 'N');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (75, 'Ñ');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (76, 'O');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (77, 'P');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (78, 'Q');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (79, 'R');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (80, 'S');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (81, 'T');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (82, 'U');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (83, 'V');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (84, 'W');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (85, 'X');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (86, 'Y');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (87, 'Z');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (88, 'AA');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (89, 'BB');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (90, 'CC');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (91, 'CHCH');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (92, 'DD');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (93, 'EE');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (94, 'FF');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (95, 'GG');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (96, 'HH');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (97, 'II');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (98, '15');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (99, '30');
INSERT INTO `local` (`idLocal`, `NombreL`) VALUES (100, '64');


#
# TABLE STRUCTURE FOR: promocion
#

DROP TABLE IF EXISTS `promocion`;

CREATE TABLE `promocion` (
  `idPromocion` int(11) NOT NULL AUTO_INCREMENT,
  `NombreP` varchar(50) NOT NULL,
  `Descripcion` varchar(100) DEFAULT NULL,
  `Imagen` varchar(30) DEFAULT NULL,
  `Vigencia` varchar(60) DEFAULT NULL,
  `Tienda_idTienda` int(11) NOT NULL,
  PRIMARY KEY (`idPromocion`),
  KEY `fk_Promocion_Tienda1_idx` (`Tienda_idTienda`),
  CONSTRAINT `fk_Promocion_Tienda1` FOREIGN KEY (`Tienda_idTienda`) REFERENCES `tienda` (`idTienda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `promocion` (`idPromocion`, `NombreP`, `Descripcion`, `Imagen`, `Vigencia`, `Tienda_idTienda`) VALUES (8, 'Relojes', 'Descuento', 'promo_2.jpg', 'Hasta Agotar Existencias', 1);
INSERT INTO `promocion` (`idPromocion`, `NombreP`, `Descripcion`, `Imagen`, `Vigencia`, `Tienda_idTienda`) VALUES (9, 'Pantallas', 'Descuentos', 'promo_1.jpg', 'Hasta Agotar Existencias', 1);
INSERT INTO `promocion` (`idPromocion`, `NombreP`, `Descripcion`, `Imagen`, `Vigencia`, `Tienda_idTienda`) VALUES (10, 'Telcel', 'Celulares', 'logo_telcel.jpg', 'Hasta Agotar Existencias', 4007);


#
# TABLE STRUCTURE FOR: tienda
#

DROP TABLE IF EXISTS `tienda`;

CREATE TABLE `tienda` (
  `idTienda` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) NOT NULL,
  `Descripcion` varchar(100) DEFAULT NULL,
  `Telefono` varchar(20) DEFAULT NULL,
  `Horario` varchar(30) DEFAULT NULL,
  `Imagen` varchar(30) DEFAULT NULL,
  `No_Local` varchar(200) NOT NULL,
  `Pagina_Web` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idTienda`)
) ENGINE=InnoDB AUTO_INCREMENT=4008 DEFAULT CHARSET=utf8;

INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (1, 'Suburbia', 'Tienda Departamental de Ropa y Calzado', '90218212', '9:00am a 9:00pm', 'logo-suburbia.jpg', '5000', 'www.suburbia.com.mx');
INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (2, 'Vips', 'Restaurante', '7654321', '8:00 am - 9:00 pm', 'logo-vips.jpg', '6000', 'www.vips.com.mx');
INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (3, 'La Michoacana', 'Heladería y Paletería', '9876543', '10:00 am - 20:00 pm', 'logo-michoacana.png', '34-37', 'www.lamichoacanaweb.com');
INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (1000, 'KIOSKO', 'Kiosko del Centro Comercial La Victoria', 'Sin Numero', 'Todos los Días', 'kiosko.jpg', '1000', '#');
INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (2000, 'BAÑOS/ESCALERAS', 'Baños del Centro Comercial', NULL, NULL, NULL, '2000', NULL);
INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (3000, 'TREN', 'Estación del Tren para niños', NULL, NULL, NULL, '3000', NULL);
INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (4000, 'MAQUINA DE REFRESCOS', 'Dispensadora de refrescos de la marca Pepsi', NULL, NULL, 'pepsi.jpg', '4000', NULL);
INSERT INTO `tienda` (`idTienda`, `Nombre`, `Descripcion`, `Telefono`, `Horario`, `Imagen`, `No_Local`, `Pagina_Web`) VALUES (4007, 'Telcel', 'Tienda de telefonía celular', '1234567', '10:00 a 19:00', 'logo_telcel.jpg', '32A', 'www.telcel.com');


#
# TABLE STRUCTURE FOR: tiendaempleo
#

DROP TABLE IF EXISTS `tiendaempleo`;

CREATE TABLE `tiendaempleo` (
  `Tienda_idTienda` int(11) NOT NULL,
  `Empleos_idEmpleos` int(11) NOT NULL,
  PRIMARY KEY (`Tienda_idTienda`,`Empleos_idEmpleos`),
  KEY `fk_Tienda_has_Empleos_Empleos1_idx` (`Empleos_idEmpleos`),
  KEY `fk_Tienda_has_Empleos_Tienda1_idx` (`Tienda_idTienda`),
  CONSTRAINT `fk_Tienda_has_Empleos_Empleos1` FOREIGN KEY (`Empleos_idEmpleos`) REFERENCES `empleo` (`idEmpleos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Tienda_has_Empleos_Tienda1` FOREIGN KEY (`Tienda_idTienda`) REFERENCES `tienda` (`idTienda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tiendaempleo` (`Tienda_idTienda`, `Empleos_idEmpleos`) VALUES (1, 4);
INSERT INTO `tiendaempleo` (`Tienda_idTienda`, `Empleos_idEmpleos`) VALUES (3, 1);


#
# TABLE STRUCTURE FOR: usuario
#

DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `idUsuarios` int(11) NOT NULL AUTO_INCREMENT,
  `User` varchar(50) NOT NULL,
  `Tipo` int(11) NOT NULL,
  `pass` varchar(45) NOT NULL,
  PRIMARY KEY (`idUsuarios`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `usuario` (`idUsuarios`, `User`, `Tipo`, `pass`) VALUES (1, 'prueba', 1, 'prueba');


